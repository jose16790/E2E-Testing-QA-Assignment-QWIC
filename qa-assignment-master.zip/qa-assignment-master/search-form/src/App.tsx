import React from 'react';
import './App.css';
import SearchBox from './componets/searchBox/SearchBox';

const SearchForm: React.FC = () => {
  return (
    <div className="App">
    <SearchBox/>
    </div>
  );
}

export default SearchForm;
